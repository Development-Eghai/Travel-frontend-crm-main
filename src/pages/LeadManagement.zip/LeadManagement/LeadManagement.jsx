import React, { useState, useEffect } from 'react';
import { Box, Button, Container, TextField, FormControl, Select, MenuItem, Grid } from '@mui/material';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import LeadTable from './LeadTable';
import LeadKanban from './LeadKanban';
import AddLeadDialog from './AddLeadDialog';
import './LeadMangment.css';  // 👈 Add this line

const LeadManagement = () => {
  const [leads, setLeads] = useState([]);
  const [viewType, setViewType] = useState('list');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [dateRange, setDateRange] = useState([null, null]);
  const [openAddLead, setOpenAddLead] = useState(false);

  // ✅ Fetch leads from YaadiGo public API
  const fetchLeads = async () => {
    try {
      const response = await fetch('https://api.yaadigo.com/public/api/enquires/');
      const data = await response.json();
      const formatted = Array.isArray(data) ? data : data?.data || [];

      // Normalize fields
      const normalized = formatted.map((item, index) => ({
        id: index + 1,
        name: item.full_name,
        email: item.email,
        mobile: item.contact_number,
        destination_type: item.destination,
        trip_type: item.hotel_category || '-',
        status: 'new',
        priority: 'medium',
        assigned_to: 'Unassigned',
        follow_up_date: null,
        created_at: item.travel_date || new Date(),
        source: 'Website',
      }));

      setLeads(normalized);
    } catch (error) {
      console.error('Error fetching leads:', error);
    }
  };

  useEffect(() => {
    fetchLeads();
  }, []);

  const handleAddNewLead = () => setOpenAddLead(true);
  const handleCloseAddLead = () => {
    setOpenAddLead(false);
    fetchLeads();
  };

  const filteredLeads = leads.filter(lead => {
    const matchesSearch =
      lead.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      lead.email?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || lead.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className='mt-4'>
      <Container maxWidth="xl">
        <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h3>Lead Management</h3>
          <Button variant="contained" color="primary" onClick={handleAddNewLead}>
            Add New Lead
          </Button>
        </Box>

        <Grid container spacing={2} sx={{ mb: 3 }}>
          <Grid item xs={12} md={3}>
            <TextField
              fullWidth
              label="Search leads..."
              variant="outlined"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </Grid>
          <Grid item xs={12} md={3}>
            <FormControl fullWidth>
              <Select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
              >
                <MenuItem value="all">All Status</MenuItem>
                <MenuItem value="new">New</MenuItem>
                <MenuItem value="contacted">Contacted</MenuItem>
                <MenuItem value="quoted">Quoted</MenuItem>
                <MenuItem value="booked">Booked</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} md={4}>
            <LocalizationProvider dateAdapter={AdapterDateFns}>
              <Box sx={{ display: 'flex', gap: 2 }}>
                <DatePicker
                  label="From Date"
                  value={dateRange[0]}
                  onChange={(newValue) => setDateRange([newValue, dateRange[1]])}
                />
                <DatePicker
                  label="To Date"
                  value={dateRange[1]}
                  onChange={(newValue) => setDateRange([dateRange[0], newValue])}
                />
              </Box>
            </LocalizationProvider>
          </Grid>
          <Grid item xs={12} md={2}>
            <FormControl fullWidth>
              <Select
                value={viewType}
                onChange={(e) => setViewType(e.target.value)}
              >
                <MenuItem value="list">List View</MenuItem>
                <MenuItem value="kanban">Kanban View</MenuItem>
              </Select>
            </FormControl>
          </Grid>
        </Grid>

        {viewType === 'list' ? (
          <LeadTable leads={filteredLeads} onRefresh={fetchLeads} />
        ) : (
          <LeadKanban leads={filteredLeads} onRefresh={fetchLeads} />
        )}

        <AddLeadDialog open={openAddLead} onClose={handleCloseAddLead} />
      </Container>
    </div>
  );
};

export default LeadManagement;
